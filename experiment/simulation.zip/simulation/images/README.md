### This folder contains all the image files used in the simulation. 
### Create sub-directories, if needed. ex: gifs/